package com.sp.restaurantlist;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Toast;

public class restaurantlist extends AppCompatActivity {
    private EditText restaurantname;
    private RadioGroup restauranttypes;
    private Button buttonsave;
    private EditText restaurantAddress;
    private EditText restaurantTel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        restaurantname= findViewById(R.id.restaurant_name);
        restauranttypes= findViewById(R.id.restaurant_types);
        buttonsave= findViewById(R.id.button_save);
        buttonsave.setOnClickListener(onSave);
    }

    private View.OnClickListener onSave= new View.OnClickListener() {
        @Override
        public void onClick(View v){
            String nameStr = restuarantname.getText().toString();
            String restType = "";
            switch (restauranttypes.getCheckedRadioButtonId()) {
                case R.id.chinese:
                    restType = "chinese";
                    break;
                case R.id.western:
                    restType = "western";
                    break;
                case R.id.indian:
                    restType = "indian";
                    break;
                case R.id.indonesian:
                    restType = "indonesian";
                    break;
                case R.id.korean:
                    restType = "korean";
                    break;
                case R.id.thai:
                    restType = "thai";
                    break;
            }
            String combineStr = nameStr + "\n" + restType;
            Toast.makeText(v.getContext(), combineStr, Toast.LENGTH_LONG).show();
        }
    };
}

